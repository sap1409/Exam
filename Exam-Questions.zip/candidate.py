import question
import os
class Candidate:
         
    def __init__(self, sid, name, time):
        self.sid = sid
        self.name = name
        self.extra_time = time
        self.exam = None
        self.confirm_details = False
        self.results = []

    def get_duration(self):
        return self.exam.duration + self.extra_time
        '''
        Returns total duration of exam.
        '''
            
    def edit_sid(self, sid):
        try:
            if type(sid) == str:
                if len(sid) == 9:
                    self.sid = sid
                    return True
        except TypeError:
            return False

        '''
        Update attribute sid
        '''

    def edit_extra_time(self, t):
        if isinstance(t, int) and t >= 0:
            self.extra_time = t
        '''
        Update attribute extra_time
        '''
    
    def set_confirm_details(self, sid, name):
        if self.sid == sid and self.name == name:
            self.confirm_details = True
        else:
            self.confirm_details = False
        return self.confirm_details
        '''
        Update attribute confirm_details
        '''

    def log_attempt(self, data):
        filename = f"{self.exam.path_to_dir}/submissions/{self.sid}.txt"
        if not(os.path.isdir(f"{self.exam.path_to_dir}/submissions")):
            os.mkdir(f"{self.exam.path_to_dir}/submissions")
        fobj = open(filename, "w")
        fobj.write(data)
        fobj.close()
        '''
        Save data into candidate's file in Submissions.
        '''
    
    def set_results(self, ls):
        if self.confirm_details == True and len(ls) == (len(self.exam.questions) - 1):
            self.results = ls
        '''
        Update attribute results if confirm_details are True
        '''
    
    def do_exam(self, preview = True):
        if preview == False:
            data = ""
            print(f"""Candidate: {self.name}({self.sid})
Exam duration: {self.get_duration()} minutes
You have {self.get_duration()} minutes to complete the exam.""")
            n = 0
            string_out = ""
            while n < len(self.exam.name):
                if self.exam.name[n] == "_":
                    string_out += " "
                else:
                    string_out += str(self.exam.name[n])
                n += 1
            answer_desc = ""
            print(f"{string_out.upper()}")
            answer_or_answers = ""
            i = 0
            x = 0
            question_no = 1
            while i < len(self.exam.questions):
                while x < len(self.exam.questions[i].answer_options):
                    answer_desc += self.exam.questions[i].answer_options[x][0] + "\n"
                    x += 1
                if self.exam.questions[i].qtype == "short" or "single":
                    answer_or_answers = "Answer"
                if self.exam.questions[i].qtype == "multiple":
                    answer_or_answers = "Answers"
                if self.exam.questions[i].qtype == "short":
                    answer_or_answers = "Answer"
                if self.exam.questions[i].qtype == "end":
                    print("-End-", end = "")
                    data += "-End-"
                else:
                    response = input(f"""Question {question_no} - {self.exam.questions[i].qtype.capitalize()} {answer_or_answers}[{self.exam.questions[i].marks}]
{self.exam.questions[i].description}
{answer_desc}Response for Question {question_no}: """)
                    marks = question.Question.mark_response(self.exam.questions[i], response)
                    data += f"""Question {question_no} - {self.exam.questions[i].qtype.capitalize()} {answer_or_answers}[{self.exam.questions[i].marks}]
{self.exam.questions[i].description}
{answer_desc}Response for Question {question_no}: {response}
You have scored {marks:.2f} marks.
\n"""
                print()
                question_no += 1
                x = 0
                answer_desc = ""
                i += 1
            self.log_attempt(data)
        else:
            print(f"""Candidate: {self.name}({self.sid})
Exam duration: {self.get_duration()} minutes
You have {self.get_duration()} minutes to complete the exam.""")
            n = 0
            string_out = ""
            while n < len(self.exam.name):
                if self.exam.name[n] == "_":
                    string_out += " "
                else:
                    string_out += str(self.exam.name[n])
                n += 1
            answer_desc = ""
            print(f"{string_out.upper()}")
            answer_or_answers = ""
            i = 0
            x = 0
            question_no = 1
            while i < len(self.exam.questions):
                while x < len(self.exam.questions[i].answer_options):
                    answer_desc += self.exam.questions[i].answer_options[x][0] + "\n"
                    x += 1
                if self.exam.questions[i].qtype == "short" or "single":
                    answer_or_answers = "Answer"
                if self.exam.questions[i].qtype == "multiple":
                    answer_or_answers = "Answers"
                if self.exam.questions[i].qtype == "short":
                    answer_or_answers = "Answer"
                if self.exam.questions[i].qtype == "end":
                    print("-End-")
                else:
                    print(f"""Question {question_no} - {self.exam.questions[i].qtype.capitalize()} {answer_or_answers}[{self.exam.questions[i].marks}]
{self.exam.questions[i].description}
{answer_desc}Response for Question {question_no}: 
""")        
                question_no += 1
                x = 0
                answer_desc = ""
                i += 1
        

    '''
    Display exam and get candidate response from terminal during the exam.
    '''
       
    def __str__(self):
        name = f"Candidate: {self.name}({self.sid})\n"
        t = self.set_duration()
        duration = f"Exam duration: {t} minutes\n"
        duration += "You have " + str(t) + " minutes to complete the exam.\n"
        if self.exam == None:
            exam = f"Exam preview: \nNone\n"
        else:
            exam = self.exam.preview_exam()
        str_out = name + duration + exam
        return str_out
