from question import Question

class Exam:
    def __init__(self, duration, path, shuffle):
        self.duration = duration
        self.path_to_dir = path
        self.shuffle = shuffle
        self.exam_status = False
        self.questions = []
        self.set_name(path)

    def set_name(self, path):
        """
        Sets the name of the exam. 
        """
        # you'll need to add some code here
        y = -1
        while True:
            if path[y] == "/":
                break
            y -= 1
        name_of_exam = path[y+1:]
        i = 0
        str_out = ""
        while i < len(name_of_exam):
            if name_of_exam[i] == " ":
                str_out += "_"
            else:
                str_out += str(name_of_exam[i])
            i += 1
        self.name = str_out

    def get_name(self):
        """
        Returns formatted string of exam name.
        """
        i = 0
        str_out = ""
        while i < len(self.name):
            if self.name[i] == "_":
                str_out += " "
            else:
                str_out += str(self.name[i])
            i += 1
        return str_out.upper()
    
    def set_exam_status(self):
        '''
        Set exam_status to True only if exam has questions.
        '''
        if len(self.questions) != 0:
            self.exam_status = True
          
    def set_duration(self, t):
        '''
        Update duration of exam.
        Parameter:
            t: int, new duration of exam.
        '''
        if isinstance(t, int) and t > 0:
            self.duration = t

    def set_questions(self, ls):
        '''
        Verifies all questions in the exam are complete.
        Parameter:
            ls: list, list of Question objects
        Returns:
            status: bool, True if set successfully.
        '''
        is_assigned = True
        if ls[-1].qtype == "end" and (ls[-1].description == None and ls[-1].answer_options == [] and ls[-1].correct_answer == None and ls[-1].marks == None):
            pass
        else:   
            is_assigned = False
            print("End marker missing or invalid")
        if isinstance(ls, list) == False:
            is_assigned = False
        else:
            i = 0
            while i < (len(ls) - 1):
                if type(ls[i]) != Question:
                    is_assigned = False
                else:
                    if ls[i].qtype != "end":
                        if ls[i].description == None or ls[i].correct_answer == None:
                            is_assigned = False
                            print("Description or correct answer missing")
                        if ls[i].qtype == "short" and ls[i].answer_options != []:
                            is_assigned = False
                            print("Answer options should not exist")
                i += 1 
            x = 0
            while x < len(ls):
                if is_assigned != False:
                    if (ls[x].qtype == "single" or ls[x].qtype == "multiple") and len(ls[x].answer_options) != 4:
                            is_assigned = False
                            print("Answer options incorrect quantity")
                x += 1
        if is_assigned == True:
            self.questions = ls
            return True
        else:
            return False
    
    def preview_exam(self):
        '''
        Returns a formatted string.
        '''
        n = 0
        string_out = ""
        while n < len(self.name):
            if self.name[n] == "_":
                string_out += " "
            else:
                string_out += str(self.name[n])
            n += 1
        answer_desc = ""
        str_out = f"{string_out.upper()}\n"
        answer_or_answers = ""
        i = 0
        x = 0
        question_no = 1
        while i < len(self.questions):
            while x < len(self.questions[i].answer_options):
                answer_desc += self.questions[i].answer_options[x][0] + "\n"
                x += 1
            if self.questions[i].qtype == "short" or "single":
                answer_or_answers = "Answer"
            if self.questions[i].qtype == "multiple":
                answer_or_answers = "Answers"
            if self.questions[i].qtype == "short":
                answer_or_answers = "Answer"
            if self.questions[i].qtype == "end":
                str_out += "-End-\n\n"
            else:
                str_out += f"""Question {question_no} - {self.questions[i].qtype.capitalize()} {answer_or_answers}[{self.questions[i].marks}]
{self.questions[i].description}
{answer_desc}Expected Answer: {self.questions[i].correct_answer}\n\n"""
            question_no += 1
            x = 0
            answer_desc = ""
            i += 1
        return str_out

    def copy_exam(self):
        '''
        Create a new exam object using the values of this instances' values.
        '''
        new_exam = Exam(self.duration, self.path_to_dir, self.shuffle)
        # make a new list of questions to reassign to the attribute
        new_questions = []
        i = 0
        while i < len(self.questions):
            # call the copy method for this question
            # TODO: (you'll need to write this instance method in Question)                
            new_question = self.questions[i].copy_question()
            # if self.shuffle == True:
            #     new_question.shuffle_answers()

            # insert this into new list of questions
            new_questions.append(new_question)
            i += 1

        # TODO: assign this new question list to the new exam
        new_exam.set_questions(new_questions)

        # return the new exam
        return new_exam
    
    def __str__(self):
        pass
