'''
Interface of the exam
'''

import setup
import program_two

def main(args):
    attempts = 0
    sid_found = False
    candidates = program_two.main(args)
    if candidates == None:
        exit(0)
    else:
        while not sid_found:
            if attempts == 3:
                print("Contact exam administrator.")
                exit(0)
            valid_sid = False
            while valid_sid == False:
                if attempts == 3:
                    print("Contact exam administrator.")
                    exit(0)
                sid = input("Enter your student identification number (SID) to start exam: ")
                if len(sid) != 9 or not(sid.isdigit()):
                    print("Invalid SID.")
                    attempts += 1
                else:
                    valid_sid = True

            if valid_sid == True:
                
                sid_found = False
                while sid_found == False:
                    i = 0
                    while i < len(candidates):
                        if candidates[i].sid == sid:
                            sid_found = True
                            candidate_no = i
                            break
                        i += 1
                    if sid_found == True:
                        break
                    
                    if sid_found != True:
                        print("Candidate number not found for exam.")
                        try_again = input("Do you want to try again [Y|N]? ")

                        
                        while try_again.lower() != "n" and try_again.lower() != "y":
                            print("Response must be [Y|N].")
                            try_again = input("Do you want to try again [Y|N]? ")                            
                        if try_again.lower() == "n":
                            exit(0)
                        else:
                            try_again_flag = True
                            attempts += 1
                            break
                        if try_again_flag == True:
                            break
                    if try_again_flag == True:
                        break

        if sid_found:
            print("Verifying candidate details...")
            while True:
                attempts += 1
                full_name = input("Enter your full name as given during registration of exam: ")
                if full_name.lower() == candidates[candidate_no].name.lower():
                    matching_name = True
                    print("Start exam....\n")
                    candidates[candidate_no].do_exam(False)
                    break
                else:
                    if attempts == 3:
                        print("Contact exam administrator to verify documents.")
                        exit(0)
                    else:
                        print("Name does not match records.")


if __name__ == "__main__":
    main(sys.argv)

