'''
Interface of the exam
'''

import exam
import setup
import sys

def parse_cmd_args(args):
    shuffle = False
    try:
        if len(args) < 3:
            raise TypeError
        duration = int(args[2])
        if len(args) >= 4:
            if args[3] == '-r':
                shuffle = True
            else:
                shuffle = False
        return (args[1], duration, shuffle)
    except TypeError:
        print("Check command line arguments")
        return None
    except ValueError:
        print("Duration must be an integer")
        return None

    '''
    Parameters:
        args: list, command line arguments
    Returns:
        result: None|tuple, details of the exam

    >>> parse_cmd_args(['program.py', '/home/info1110/', '60', '-r'])
    ('/home/info1110/', 60, True)

    >>> parse_cmd_args(['program.py', '/home/info1110/', 'ab', '-r'])
    Duration must be an integer

    >>> parse_cmd_args(['program.py', '/home/info1110/'])
    Check command line arguments
    '''

def setup_exam(obj):    
    '''
    Update exam object with question contents extracted from file 
    Parameter:
        obj: Exam object
    Returns:
        (obj, status): tuple containing updated Exam object and status
        where status: bool, True if exam is setup successfully. Otherwise, False.
    '''
    filename = open(obj.path_to_dir + "/questions.txt")
    obj.set_questions(setup.extract_questions(filename))
    obj.set_exam_status()
    return (obj, obj.exam_status)

def main(args):
    successful_setup = True
    try:
        parse = parse_cmd_args(args)
        questions = open(args[1] + "/questions.txt", "r")
        students = open(args[1] + "/students.csv", "r")
    except FileNotFoundError:
        if parse != None:
            print("Missing files")
            successful_setup = False
            return False
    finally:
        if successful_setup == True:
            
            if parse != None:
                examobj = exam.Exam(parse[1], parse[0], parse[2])
                print("Setting up exam...")
                setup = setup_exam(examobj)
                if setup[1] == True:
                    print("Exam is ready...")
                    def want_preview():
                        preview = False
                        while True:
                            want_preview = input("Do you want to preview the exam [Y|N]? ").lower()
                            if want_preview == 'y' or want_preview == "n":
                                if want_preview == "y":
                                    print(setup[0].preview_exam()[:-1])
                                    preview = True
                                elif want_preview == "n":
                                    break
                            else:
                                print("Invalid command.")
                        return preview
                    want_preview()
                    return setup
                else:
                    print("Error setting up exam")
                    return False

    '''
    Implement all stages of exam process.
    '''
    
if __name__ == "__main__":
    '''
    DO NOT REMOVE
    '''
    main(sys.argv)
