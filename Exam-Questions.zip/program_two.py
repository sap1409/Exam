'''
Interface of the exam
'''
import sys
import setup
import program_one
import os

def assign_exam(exam_obj):
    candidates = setup.extract_students(open(exam_obj.path_to_dir + "/students.csv", "r"))
    if len(candidates)>0:
        print("Assigning exam to candidates...")
        i = 0
        while i < len(candidates):
            new_exam = exam_obj.copy_exam()
            if new_exam.shuffle:
                j = 0
                while j < len(new_exam.questions):
                    new_exam.questions[j].shuffle_answers()
                    j += 1
            candidates[i].exam = new_exam
            i += 1
        print(f"Complete. Exam allocated to {len(candidates)} candidates.")
        return candidates
    else:
        print("No candidates found in the file")
        return None

def main(args):
    setup_returns = program_one.main(args)
    if setup_returns != None:
        if os.path.exists(args[1]):
            if setup_returns != False:
                candidates = assign_exam(setup_returns[0])
                while True:
                    preview_student_exam = str(input("Enter SID to preview student's exam (-q to quit): "))
                    if preview_student_exam == "-q":
                        break
                    elif preview_student_exam == "-a":
                        i = 0
                        while i < len(candidates):
                            candidates[i].do_exam()
                            print("")
                            i += 1
                    else:
                        if len(preview_student_exam) == 9 and preview_student_exam.isdigit():
                            i = 0 
                            sid_valid = False
                            while i < len(candidates):
                                if candidates[i].sid == preview_student_exam:
                                    sid_valid = True
                                    candidates[i].do_exam()
                                    print("")
                                    break
                                i += 1
                            if not sid_valid:
                                print("SID not found in list of candidates.\n")
                        else:
                            print("SID is invalid.\n")
                return candidates
        else:
            return None

if __name__ == "__main__":
    main(sys.argv)
