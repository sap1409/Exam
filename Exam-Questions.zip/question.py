import random

class Question:
    
    def __init__(self, qtype):
        # you'll need to check if qtype is valid before assigning it
        if qtype.lower() == "single" or qtype.lower() == "multiple" or qtype.lower() == "short" or qtype.lower() == "end":
            self.qtype = qtype
        else:
            self.qtype = None
        self.description = None
        self.answer_options = []
        self.correct_answer = None
        self.marks = None
       
    def set_type(self, qtype):
        # set_type returns True if the qtype is valid otherwise returns False
        if qtype.lower() == "single" or qtype.lower() == "multiple" or qtype.lower() == "short" or qtype.lower() == "end":
            self.qtype = qtype
            return True
        else:
            return False
        """
        Update instance variable qtype.
        """
    
    def set_description(self, desc):
        if self.qtype.lower() == 'end':
            return False
        if type(desc) == str and len(desc) != 0:
            self.description = desc
            return True
        else:
            return False
        """
        Update instance variable description.
        """
    
    def set_correct_answer(self, ans):
        if self.qtype == "end":
            return False
        possible_answers = ['A', 'B', 'C', 'D']
        given_ans = ans.upper().strip().split(", ")
        n = 0
        valid_ans = False
        while n < len(given_ans):
            if possible_answers.count(given_ans[n])>0:
                valid_ans = True
            else:
                valid_ans = False
                break
            n += 1
        if type(ans) == str:
            if self.qtype.lower() == 'short':
                self.correct_answer = ans
            elif self.qtype.lower() == 'single':
                if len(given_ans) == 1 and valid_ans == True:
                    self.correct_answer = ans
                else:
                    pass
            elif self.qtype.lower() == 'multiple':
                if len(given_ans) >= 1 and valid_ans == True:
                    self.correct_answer = ans
                else:
                    pass
        
        if self.correct_answer == ans:
            return True
        else:
            return False
        """
        Update instance variable correct_answer.
        """
    
    def set_marks(self, num):
        if self.qtype == 'end':
            return False
        if isinstance(num,int) and num >= 0:
            self.marks = num
            return True
        else:
            return False
        """
        Update instance variable marks.
        """
    
    def set_answer_options(self, opts):
        tuple_list = False
        flag = False
        if self.qtype == "short" or self.qtype == "end":
            self.answer_options = opts
            return True
        elif isinstance(opts, list):
            i = 0
            while i < len(opts):
                if isinstance(opts[i], tuple) and len(opts[i]) == 2 and isinstance(opts[i][0], str) and isinstance(opts[i][1], bool):
                    tuple_list = True
                else:
                    tuple_list = False
                    break
                i += 1
            if len(opts) == 4 and (opts[0][0].startswith("A.") and opts[1][0].startswith("B.") and opts[2][0].startswith("C.") and opts[3][0].startswith("D.")) and isinstance(self.correct_answer, str):
                if self.qtype == "single" and len(self.correct_answer.strip(", ")) == 1:
                    flag = True
                elif self.qtype == "multiple" and len(self.correct_answer.strip(", ")) >= 1:
                    flag = True
            if tuple_list and flag:
                opts_default = [False, False, False, False]
                n = 0
                correct_answer_list = self.correct_answer.strip().split(", ")
                while n < len(opts):
                    j = 0 
                    while j < len(correct_answer_list):
                        if correct_answer_list[j] == opts[n][0][0]:
                            opts_default[n] = True
                            break
                        j += 1
                    n += 1
                self.answer_options = [(opts[0][0],opts_default[0]),(opts[1][0],opts_default[1]),(opts[2][0],opts_default[2]),(opts[3][0],opts_default[3])]
                return True
        return False

        """
        Update instance variable answer_options.

        opts should have all flags equal to False when passed in.
        This method will update the flags based on the correct answer.
        Only then do we check that the number of correct answers is correct.
        """

    def get_answer_option_descriptions(self):
        i = 0
        answer_desc = ""
        if self.qtype == 'short' or self.qtype == 'end':
            return ""
        else:
            while i < len(self.answer_options):
                answer_desc += self.answer_options[i][0] + "\n"
                i += 1
            return answer_desc[:-1]
        """
        Returns formatted string listing each answer description on a new line.
        Example:
        A. Answer description
        B. Answer description
        C. Answer description
        D. Answer description
        """

    def mark_response(self, response):
        if type(response) == int:
            marks = 0
            return marks
        response_multiple_valid = False
        if self.qtype == "multiple":
            response_split = response.strip().split(", ")
            i = 0
            while i < len(response_split):
                if (response_split[i] == "A") or (response_split[i] == "B") or (response_split[i] == "C") or (response_split[i] == "D"):
                    response_multiple_valid = True
                else:
                    response_multiple_valid = False
                    break
                i += 1
        marks = 0
        if self.qtype == "single" and (len(response) == 1) and (response == "A" or response == "B" or response == "C" or response == "D"):
            if response == self.correct_answer:
                marks = self.marks
        elif self.qtype == "multiple" and (len(response.strip().split(", ")) <= 4) and response_multiple_valid:
            per_marks = self.marks/len(self.correct_answer.split(", "))
            i = 0
            while i < len(response.split(", ")):
                if self.correct_answer.split(", ").count(response.split(", ")[i]) > 0:
                    marks += per_marks
                i += 1
        elif self.qtype == "short":
            if response == self.correct_answer:
                marks = self.marks
        return marks
        """
        Check if response matches the expected answer
        Parameter:
            response: str, response provided by candidate
        Returns:
            marks: int|float, marks awarded for the response.
        """
        pass

    def preview_question(self, i=0, show=True):
        answer_desc = ""
        x = 0
        while x < len(self.answer_options):
            answer_desc += self.answer_options[x][0] + "\n"
            x += 1
        if i == 0:
            i = "X"
        if self.qtype == "single":
            return f"""Question {i} - {self.qtype.capitalize()} Answer[{self.marks}]\n{self.description}\n{answer_desc}Expected Answer: {self.correct_answer}"""
        elif self.qtype == "multiple":
            return f"""Question {i} - {self.qtype.capitalize()} Answers[{self.marks}]\n{self.description}\n{answer_desc}Expected Answer: {self.correct_answer}"""
        elif self.qtype == "short":
            return f"""Question {i} - {self.qtype.capitalize()} Answer[{self.marks}]\n{self.description}\nExpected Answer: {self.correct_answer}"""
        """
        Returns formatted string showing details of question.
        Parameters:
            i: int, placeholder for question number, DEFAULT = 0
            show: bool, True to show Expected Answers, DEFAULT = TRUE
        """

    def generate_order():
        ls = []
        i = 0
        while i < 4:
            random_int = random.randint(0, 3)
            if ls.count(random_int) == 0:
                ls.append(random_int)
                i += 1

        return ls
        """
        Returns a list of 4 integers between 0 and 3 inclusive to determine order.

        Sample usage:
        >>> generate_order()
            [3,1,0,2]
        """

    def shuffle_answers(self):
        if self.qtype == "single" or self.qtype == "multiple":
            order = Question.generate_order()
            answer_opts = ["A.", "B.", "C.", "D."]
            answer_opts_copy = self.answer_options.copy()
            correct_answer = ""
            z = 0
            while z < 4:
                self.answer_options[z] = (str(chr(z + 65)) + answer_opts_copy[order[z]][0][1:], answer_opts_copy[order[z]][1])
                if answer_opts_copy[order[z]][1]:
                    correct_answer += str(chr(z + 65)) + ", "
                z += 1
            self.correct_answer = correct_answer[:-2]

        """
        Updates answer options with shuffled elements.
        Must call generate_order only once.
        """

    def copy_question(self):

        new_question = Question(self.qtype)
        new_question.set_description(self.description)
        new_question.set_correct_answer(self.correct_answer)
        new_question.set_answer_options(self.answer_options)
        new_question.set_marks(self.marks)

        return new_question
      

    def __str__(self):
        '''
        You are free to change this, this is here for your convenience.
        When you print a question, it'll print this string.
        '''
        return f'''Question {self.__hash__()}:
Type: {self.qtype}
Description: {self.description}
Possible Answers: {self.get_answer_option_descriptions()}
Correct answer: {self.correct_answer}
Marks: {self.marks}
'''
