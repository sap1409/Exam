'''
Functions to setup the exam questions and candidate list for the exam.
'''
# please do not change or add another import
import question
import candidate
import io

def extract_questions(fobj)->list:
    corr_answer = ""
    options = []
    marks = 0
    desc_set = False
    answer_set = False
    qtype = ""
    list_questions = []
    i = 0
    while True:
        assignment = False
        line = fobj.readline()
        if line == "":
            list_questions.append(question.Question("end"))
            break
        if line.startswith("Question - "):
            qtype = str(line[11:].strip()).lower()
            list_questions.append(question.Question(qtype))
            desc = ""
            desc_set = True
        if desc_set == True:
            if not (line.startswith("Question - ") or line.startswith("Possible Answers:") or line.startswith("Expected Answer:")):
                desc += line
            if line.startswith("Possible Answers:") or line.startswith("Expected Answer:"):
                desc = desc[:-1]
                list_questions[i].set_description(desc)
                desc = ""
                desc_set = False
                answer_set = True
        if line.startswith("Expected Answer:"):
            answer_set = False
        if answer_set == True and not (line.startswith("Possible Answers:")):
            options.append((str(line.strip()), False))
        if line.startswith("Expected Answer:"):
            corr_answer = str(line[17:].strip())
        if line.startswith("Marks: "):
            list_questions[i].set_correct_answer(corr_answer)
            corr_answer = ""
            marks += int(line[7:].strip())
            assignment = True
        if assignment == True:
            list_questions[i].set_marks(marks)
            list_questions[i].set_answer_options(options)
            options = []
            marks = 0
            i += 1

    return list_questions

    """
    Parses fobj to extract details of each question found in the file.
    General procedure to extract question.
    1. Extract the following
        - type
        - question details (description)
        - possible answers (if any)
        - expected answer
        - marks
        (you shouldn't need to perform error handling on these details,
        this is handled in the next step).
    2. You'll need to convert the possible answers (if any) to a list of tuples (see 
       "Section 1. Setup the exam - Question" for more details). All flags can be False.
    3. Create a question object and call the instance methods to set the
       attributes. This will handle the error handling.
    4. Repeat Steps 1-3 for the next question until there are no more questions.
    5. You will need to create an end question as well.
    6. Create the list for all your questions and return it.

    Parameter:
        fobj: open file object in read mode
    Returns:
        result: list of Question objects.
    """


def sort(to_sort: list, order: int=0)->list:
    new_list = to_sort.copy()
    if isinstance(to_sort, list) == False:
        return []
    else:
        if order == 1:
            i = 0
            while i < (len(new_list) - 1):
                j = 0
                while j  < (len(new_list) - i - 1):
                    temp = new_list[j]
                    if new_list[j] > new_list[j + 1]:
                        new_list[j] = new_list[j + 1]
                        new_list[j + 1] = temp
                    j += 1
                i += 1
        elif order == 2:
            i = 0
            while i < (len(new_list) - 1):
                j = 0
                while j  < (len(new_list) - i - 1):
                    temp = new_list[j]
                    if new_list[j] < new_list[j + 1]:
                        new_list[j] = new_list[j + 1]
                        new_list[j + 1] = temp
                    j += 1
                i += 1
    
    return new_list
    """
    Sorts to_sort depending on settings of order.

    Parameters:
        to_sort: list, list to be sorted.
        order: int, 0 - no sort, 1 - ascending, 2 - descending
    Returns
        result: list, sorted results.

    Sample usage:
    >>> to_sort = [(1.50, "orange"), (1.02, "apples"), (10.40, "strawberries")]
    >>> print("Sort 0:", sort(to_sort, 0))
    Sort 0: [(1.5, 'orange'), (1.02, 'apples'), (10.4, 'strawberries')]
    >>> print("Sort 1:", sort(to_sort, 1))
    Sort 1: [(1.02, 'apples'), (1.5, 'orange'), (10.4, 'strawberries')]
    >>> print("Sort 2:", sort(to_sort, 2))
    Sort 2: [(10.4, 'strawberries'), (1.5, 'orange'), (1.02, 'apples')]
    >>> to_sort = [ "oranges", "apples", "strawberries"]
    >>> print("Sort 0:", sort(to_sort, 0))
    Sort 0: ['oranges', 'apples', 'strawberries']
    >>> print("Sort 1:", sort(to_sort, 1))
    Sort 1: ['apples', 'oranges', 'strawberries']
    >>> print("Sort 2:", sort(to_sort, 2))
    Sort 2: ['strawberries', 'oranges', 'apples']
    """

def extract_students(fobj)->list:
    candidates = []
    ls = []
    try:
        while True:
            line = fobj.readline()
            if line == "":
                break
            if line.startswith("SID"):
                continue
            line_strip = line.strip().split(",")
            sid = line_strip[0]
            name = line_strip[1]
            extra_time = line_strip[2]
            if extra_time == "":
                extra_time = 0
            ls.append((sid, name, extra_time))
    except FileNotFoundError:
        candidates = []
    finally:
        ls = sort(ls, 1)
        i = 0
        while i < len(ls):
            candidates.append(candidate.Candidate(ls[i][0], ls[i][1], int(ls[i][2])))
            i += 1
        return candidates

    """
    Parses fobj to extract details of each student found in the file.

    Parameter:
        fobj: open file object in read mode
    Returns:
        result: list of Candidate objects sorted in ascending order
    """
