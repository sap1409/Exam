# Test Case Designs
Complete the given tables with details of your test case design for each question type.
State the values to initalize appropriate `Question` objects required for the test case.

Column descriptions:
* Test ID - Test case identification number
* Description - Type of testcase and brief explanation of test case details
* Inputs - Arguments into the method
* Expected Output - Return values of the method
* Status - pass/fail 

Table 1: Summary of test cases for method `mark_response` for question type `short`

| Test ID | Description |          Inputs          |                 Expected Output                    | Status |
| ------- | ----------- | ------------------------ | -------------------------------------------------- | ------ |
|    1    |  Positive   | correct_answer = "bob"   | Correct, you have scored 1 marks.                  |  pass  |
|         |  Testcase:  | marks = 1                | Positive test case for "short" qtype passed.       |        |
|         |  response   | response = "bob"         |                                                    |        |
|         |  is same as |                          |                                                    |        |
|         |  correct    |                          |                                                    |        |
|         |  answer.    |                          |                                                    |        |
| ------- | ----------- | ------------------------ | -------------------------------------------------- | ------ |
|    2    |  Negative   | correct_answer = "bob"   | You have scored 0 marks.                           |  pass  |
|         |  Testcase:  | marks = 1                | Negative test case for "short" qtype passed.       |        |
|         |  response   | response = "b0b"         |                                                    |        |
|         |  has an int |                          |                                                    |        |
|         |  type       |                          |                                                    |        |
|         |  character  |                          |                                                    |        |
|         |  type       |                          |                                                    |        |
|         |  casted     |                          |                                                    |        |
|         |  to string  |                          |                                                    |        |       

Table 2: Summary of test cases for method `mark_response` for question type `single`

| Test ID | Description |          Inputs          |                 Expected Output                    | Status |
| ------- | ----------- | ------------------------ | -------------------------------------------------- | ------ |
|    1    |  Positive   | correct_answer = "A"     | Correct, you have scored 1 marks.                  |  pass  |
|         |  Testcase:  | marks = 1                | Positive test case for "single" qtype passed.      |        |
|         |  response   | response = "A"           |                                                    |        |
|         |  is same as |                          |                                                    |        |
|         |  correct    |                          |                                                    |        |
|         |  answer.    |                          |                                                    |        |
| ------- | ----------- | ------------------------ | -------------------------------------------------- | ------ |
|    2    |  Negative   | correct_answer = "A"     | You have scored 0 marks.                           |  pass  |
|         |  Testcase:  | marks = 1                | Negative test case for "single" qtype passed.      |        |
|         |  response   | response = 0             |                                                    |        |
|         |  is of type |                          |                                                    |        |
|         |  int,       |                          |                                                    |        |
|         |  type       |                          |                                                    |        |
|         |  casted     |                          |                                                    |        |
|         |  to string  |                          |                                                    |        |       


Table 3: Summary of test cases for method `mark_response` for question type `multiple`

| Test ID | Description |          Inputs          |                 Expected Output                    | Status |
| ------- | ----------- | ------------------------ | -------------------------------------------------- | ------ |
|    1    |  Positive   | correct_answer = "A, B"  | Correct, you have scored 2.0 marks.                |  pass  |
|         |  Testcase:  | marks = 2                | Positive test case for "multiple" qtype passed.    |        |
|         |  response   | response = "A, B"        |                                                    |        |
|         |  is same as |                          |                                                    |        |
|         |  correct    |                          |                                                    |        |
|         |  answer.    |                          |                                                    |        |
| ------- | ----------- | ------------------------ | -------------------------------------------------- | ------ |
|    2    |  Negative   | correct_answer = "A, B"  | You have scored 0 marks.                           |  pass  |
|         |  Testcase:  | marks = 2                | Negative test case for "multiple" qtype passed.    |        |
|         |  response   | response = ""            |                                                    |        |
|         |  is an      |                          |                                                    |        |
|         |  empty      |                          |                                                    |        |
|         |  string.    |                          |                                                    |        |

# 
