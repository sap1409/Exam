'''
The arguments in the functions are passed in the format ({correctanswer}, {total marks of the question}, {response}).
Then the program runs the functions by calling them with appropriate arguments/parameters.
'''
import question
import sys

def positive_single(correct_answer, marks, response):
    """
    Checks whether the given response is a positive testcase for 
    qtype single or not, assert function returns an error if the positive testcase fails.
    Here, assert function checks if the given marks is equal to the total marks of the question.
    """
    question_pos_single = question.Question("single")
    question_pos_single.set_correct_answer(correct_answer)
    question_pos_single.set_marks(marks)
    marks_awarded = question_pos_single.mark_response(response)
    assert marks_awarded == marks, "Postive test case for \"single\" type question fails."
    return f"Correct, you have scored {marks_awarded} marks.\nPositive test case for \"single\" qtype passed."

def negative_single(correct_answer, marks, response):
    """
    Checks whether the given response is a negative testcase for 
    qtype single or not, assert function returns an error if the negative testcase fails.
    Here, assert function checks if the given marks is not equal to the total marks of the question or not.
    """
    question_neg_single = question.Question("single")
    question_neg_single.set_correct_answer(correct_answer)
    question_neg_single.set_marks(marks)
    marks_awarded = question_neg_single.mark_response(response)
    assert marks_awarded != marks, "Negative test case for \"single\" type question fails."
    return f"You have scored {marks_awarded} marks.\nNegative test case for \"single\" qtype passed."

def positive_multiple(correct_answer, marks, response):
    """
    Checks whether the given response is a positive testcase for 
    qtype multiple or not, assert function returns an error if the positive testcase fails.
    Here, assert function checks if the given marks is not equal to 0 or not.
    """
    question_pos_multiple = question.Question("multiple")
    question_pos_multiple.set_correct_answer(correct_answer)
    question_pos_multiple.set_marks(marks)
    marks_awarded = question_pos_multiple.mark_response(response)
    assert marks_awarded != 0, "Positive test case for \"multiple\" type question fails."
    if marks_awarded != marks:
        return f"Partially correct, you have scored {marks_awarded} marks.\nPositive test case for \"multiple\" qtype passed."
    elif marks_awarded == marks:
        return f"Correct, you have scored {marks_awarded} marks.\nPositive test case for \"multiple\" qtype passed."
    
def negative_multiple(correct_answer, marks, response):
    """
    Checks whether the given response is a negative testcase for 
    qtype multiple or not, assert function returns an error if the negative testcase fails.
    Here, assert function checks if the given marks is equal to 0.
    """
    question_neg_multiple = question.Question("multiple")
    question_neg_multiple.set_correct_answer(correct_answer)
    question_neg_multiple.set_marks(marks)
    marks_awarded = question_neg_multiple.mark_response(response)
    assert marks_awarded == 0, "Negative test case for \"multiple\" type question fails."
    return f"You have scored {marks_awarded} marks.\nNegative test case for \"multiple\" qtype passed."

def positive_short(correct_answer, marks, response):
    """
    Checks whether the given response is a positive testcase for 
    qtype short or not, assert function returns an error if the positive testcase fails.
    Here, assert function checks if the given marks is equal to the total marks of the question or not.
    """
    question_pos_short = question.Question("short")
    question_pos_short.set_correct_answer(correct_answer)
    question_pos_short.set_marks(marks)
    marks_awarded = question_pos_short.mark_response(response)
    assert marks_awarded == marks, "Positive test case for \"short\" type question fails."
    return f"Correct, you have scored {marks_awarded} marks.\nPositive test case for \"short\" qtype passed."

def negative_short(correct_answer, marks, response):
    """
    Checks whether the given response is a negative testcase for 
    qtype short or not, assert function returns an error if the negative testcase fails.
    Here, assert function checks if the given marks is not equal to the total marks of the question or not.
    """
    question_neg_short = question.Question("short")
    question_neg_short.set_correct_answer(correct_answer)
    question_neg_short.set_marks(marks)
    marks_awarded = question_neg_short.mark_response(response)
    assert marks_awarded != marks, "Negative test case for \"short\" type question fails."
    return f"You have scored {marks_awarded} marks.\nNegative test case for \"short\" qtype passed."

#POSITIVE TESTCASE FOR SINGLE QTYPE
"""POSITIVE TESTCASE FOR SINGLE QTYPE"""
print()
print("-------------------------------------------------")
print("POSITIVE TESTCASE FOR SINGLE QTYPE")
print(positive_single("A", 1, "A"))
print("-------------------------------------------------")
print()

#NEGATIVE TESTCASE FOR SINGLE QTYPE
"""NEGATIVE TESTCASE FOR SINGLE QTYPE"""
print()
print("-------------------------------------------------")
print("NEGATIVE TESTCASE FOR SINGLE QTYPE")
print(negative_single("A", 1, 0)) #response is integer
print("-------------------------------------------------")
print()

#POSITIVE TESTCASE FOR MULTIPLE QTYPE
"""POSITIVE TESTCASE FOR MULTIPLE QTYPE"""
print()
print("-------------------------------------------------")
print("POSITIVE TESTCASE FOR MULTIPLE QTYPE")
print(positive_multiple("A, B", 2, "A, B"))
print("-------------------------------------------------")
print()

#NEGATIVE TESTCASE FOR MULTIPLE QTYPE
"""NEGATIVE TESTCASE FOR MULTIPLE QTYPE"""
print()
print("-------------------------------------------------")
print("NEGATIVE TESTCASE FOR MULTIPLE QTYPE")
print(negative_multiple("A, B", 2, "")) #response is an empty string
print("-------------------------------------------------")
print()

#POSITIVE TESTCASE FOR SHORT QTYPE"
"""POSITIVE TESTCASE FOR SHORT QTYPE"""
print()
print("-------------------------------------------------")
print("POSITIVE TESTCASE FOR SHORT QTYPE")
print(positive_short("bob", 1, "bob"))
print("-------------------------------------------------")
print()

#NEGATIVE TESTCASE FOR SHORT QTYPE"
"""NEGATIVE TESTCASE FOR SHORT QTYPE"""
print()
print("-------------------------------------------------")
print("NEGATIVE TESTCASE FOR SHORT QTYPE")
print(negative_short("bob", 1, "b0b")) #response has an int type character typecasted to string
print("-------------------------------------------------")
print()
